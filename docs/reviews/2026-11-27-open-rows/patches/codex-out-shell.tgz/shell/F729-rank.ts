import { tempLibrary } from "../../packages/core/test/helpers";
import { createItem } from "../../packages/core/src/items";
import { openIndex } from "../../packages/core/src/db";
import { queryTerms, retrieve } from "../../packages/core/src/ai/ask";
import { rmSync } from "node:fs";
const lib = await tempLibrary();
try {
 const query = "How do spaced repetition and the forgetting curve relate?";
 for (let n=0;n<8;n++) await createItem(lib, { type: "article", title: `Spaced repetition and the forgetting curve ${n}`, body: "Spaced repetition revisits material on later days instead of cramming." });
 const b = await createItem(lib, {type:"article",title:"A memory textbook",body:`## Background\n\n${"Unrelated context. ".repeat(3000)}\n\n## Forgetting\n\nThe forgetting curve shows recall declining over time.`});
 const index = openIndex(lib); try { const ids=index.sourcesMatching(queryTerms(query),-1); console.log(ids.indexOf(b.meta.id), ids.length, retrieve(lib,query).map(p=>p.title)); } finally {index.close();}
} finally { rmSync(lib.root,{recursive:true,force:true}); }
