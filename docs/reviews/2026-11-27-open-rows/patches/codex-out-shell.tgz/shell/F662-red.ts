// Isolated reproduction of the real install hook. No Git writes, app builds, or server.
import { mkdirSync, mkdtempSync, writeFileSync, readFileSync, rmSync, chmodSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { strict as assert } from "node:assert";
const dir = mkdtempSync(join(tmpdir(), "ore-stale-hook-"));
try {
  const bin = join(dir, "bin"), cache = join(dir, "cache"), marker = join(dir, "installed");
  mkdirSync(bin); mkdirSync(cache);
  const lock = join(cache, "app-install.lock");
  mkdirSync(lock);
  const pid = 2147483647;
  assert.throws(() => process.kill(pid, 0), { code: "ESRCH" });
  writeFileSync(join(lock, "owner.json"), JSON.stringify({ pid, started: "2026-01-01T00:00:00Z" }));
  for (const [name, body] of Object.entries({
    git: `case "$1" in rev-parse) case "$2" in --abbrev-ref) echo master;; --show-toplevel) echo '${dir}';; *) echo test-head;; esac;; diff-tree) echo apps/desktop/a.ts;; esac`,
    bun: `touch '${marker}'`,
    lsappinfo: "exit 0",
  })) { writeFileSync(join(bin, name), `#!/bin/sh\n${body}\n`); chmodSync(join(bin, name), 0o755); }
  const hook = readFileSync(resolve(".githooks/post-commit"), "utf8").replace('cache="$HOME/Library/Caches/ore"', `cache='${cache}'`);
  writeFileSync(join(dir, "hook"), hook);
  const p = Bun.spawn(["sh", join(dir, "hook")], { env: { ...process.env, PATH: `${bin}:${process.env.PATH}`, ORE_INSTALL_RETRY: "1" }, stdout: "pipe", stderr: "pipe" });
  await Promise.all([new Response(p.stdout).text(), new Response(p.stderr).text(), p.exited]);
  // The hook backgrounds its runner; the stale lock makes it exit immediately.
  await Bun.sleep(100);
  assert.ok(existsSync(marker), "F662: a dead owner's lock still prevents the install hook from running");
} finally { rmSync(dir, { recursive: true, force: true }); }
