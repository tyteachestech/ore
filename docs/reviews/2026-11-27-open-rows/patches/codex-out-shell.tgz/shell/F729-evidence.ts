import { tempLibrary } from "../../packages/core/test/helpers";
import { addBig, addGolden, loadAskCases, asked, passagesFor, retrieved } from "../../packages/core/eval/ask";
import { rmSync } from "node:fs";
const lib = await tempLibrary();
try {
 addBig(lib.root); const names = await addGolden(lib);
 for (const c of [...loadAskCases().cases, ...loadAskCases().hard]) {
  const ps=passagesFor(lib,"tutor",asked(c,names));
  if (!retrieved(c,ps,names)) console.log(JSON.stringify({c, passages:ps.map(p=>({source:names.get(p.item)||p.title,text:p.text.slice(0,350)}))}));
 }
} finally { rmSync(lib.root,{recursive:true,force:true}); }
