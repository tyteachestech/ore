import { expect, test } from "bun:test";
import { rmSync } from "node:fs";
import { retrieve, queryTerms, PASSAGES } from "../../packages/core/src/ai/ask";
import { tutorPassages } from "../../packages/core/src/ai/tutor";
import { createItem, findItem, setItemArchived } from "../../packages/core/src/items";
import { openIndex } from "../../packages/core/src/db";
import { tempLibrary } from "../../packages/core/test/helpers";

test("F729: Ask and tutor retain evidence in a ninth-ranked source, within the passage budget", async () => {
  const lib = await tempLibrary();
  try {
    const question = "How do spaced repetition and the forgetting curve relate?";
    const first: string[] = [];
    for (let n = 0; n < 8; n++) {
      const item = await createItem(lib, { type: "article", title: `Spaced repetition and the forgetting curve ${n}`, body:
        Array.from({ length: 3 }, (_, i) => `## Practice ${i}\n\nSpaced repetition revisits material on later days instead of cramming.`).join("\n\n") });
      first.push(item.meta.id);
    }
    const evidence = "The forgetting curve shows recall declining over time.";
    const textbook = await createItem(lib, { type: "article", title: "A memory textbook", body:
      `## Background\n\n${"Unrelated context. ".repeat(3000)}\n\n## Forgetting\n\n${evidence}` });
    const index = openIndex(lib);
    try { expect(index.sourcesMatching(queryTerms(question), -1).indexOf(textbook.meta.id)).toBe(8); }
    finally { index.close(); }
    for (const passages of [retrieve(lib, question), tutorPassages(lib, question, {})]) {
      expect(passages.some((p) => p.item === textbook.meta.id && p.text.includes(evidence))).toBe(true);
      expect(passages.some((p) => first.includes(p.item))).toBe(true);
      expect(passages.length).toBeLessThanOrEqual(PASSAGES);
      for (const id of new Set(passages.map((p) => p.item))) expect(passages.filter((p) => p.item === id).length).toBeLessThanOrEqual(5);
      for (const p of passages) expect(findItem(lib, p.item).body.slice(p.start, p.end)).toBe(p.text);
    }
    expect(retrieve(lib, question, PASSAGES, first[0]!).every((p) => p.item === first[0])).toBe(true);
    await setItemArchived(lib, textbook.meta.id, true);
    expect(retrieve(lib, question).some((p) => p.item === textbook.meta.id)).toBe(false);
  } finally { rmSync(lib.root, { recursive: true, force: true }); }
});
