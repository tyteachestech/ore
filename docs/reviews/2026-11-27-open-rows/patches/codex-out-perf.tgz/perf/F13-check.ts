// Check the reported missing pieces without a browser, server or native process.
import { strict as assert } from "node:assert";
import { mkdtempSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { createItem } from "../../packages/core/src/items";
import { transcriptOf } from "../../packages/core/src/ingest/youtube";
import { audioOf } from "../../packages/core/src/ingest/index";
const root = mkdtempSync(join(tmpdir(), "ore-perf-phone-"));
try {
  const lib = { root };
  const vtt = "WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nHello learning\n";
  const youtube = await createItem(lib, { type: "youtube", title: "Video", url: "https://www.youtube.com/watch?v=abcdefghijk", body: "[00:01] Hello learning" });
  const audio = await createItem(lib, { type: "audio", title: "Audio", body: "[00:01] Hello learning" });
  writeFileSync(join(youtube.dir, "source.vtt"), vtt);
  writeFileSync(join(audio.dir, "transcript.vtt"), vtt);
  writeFileSync(join(audio.dir, "source.mp3"), "stand-in bytes; not played");
  const config = readFileSync("apps/desktop/vite.config.ts", "utf8");
  const code = config.slice(config.indexOf("function snapshot()"), config.indexOf("// The core imports its prompts"));
  const snapshot = new Function("process", "readFileSync", "readdirSync", "join", new Bun.Transpiler({ loader: "ts" }).transformSync(code) + "; return snapshot();")({ env: { ORE_PHONE_LIBRARY: root } }, readFileSync, readdirSync, join);
  assert.equal(Object.values(snapshot).filter((v) => v === vtt).length, 2);
  assert.equal(transcriptOf(youtube)?.words[0]?.[0], 1);
  assert.equal(audioOf(audio)?.words[0]?.[0], 1);
  const native = readFileSync("apps/phone/src-tauri/src/lib.rs", "utf8");
  assert(native.includes('".vtt"'));
  assert(native.includes('fn player_port()'));
  assert(native.includes('include_str!("../../../desktop/src-tauri/src/player.html")'));
  const phone = readFileSync("apps/desktop/src/phone/PhoneApp.tsx", "utf8");
  const reader = readFileSync("apps/desktop/src/Reader.tsx", "utf8");
  assert(phone.includes('import { Reader } from "../Reader"'));
  assert(reader.includes('from "./transcript"'));
  console.log("F13 NOT REPRODUCED: snapshot keeps both VTTs; core returns timed video/audio words; phone uses shared Reader/transcript and has native player relay. Actual playback remains untested.");
} finally { rmSync(root, { recursive: true, force: true }); }
