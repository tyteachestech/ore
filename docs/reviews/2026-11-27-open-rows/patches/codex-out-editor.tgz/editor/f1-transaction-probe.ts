// Why removing the key and using one replacement is not a durable F1 fix.
import { Window } from "../../apps/desktop/node_modules/happy-dom";
const w = new Window();
for (const k of ["window", "document", "HTMLElement", "Node", "MutationObserver", "getComputedStyle"] as const) {
  const v = (w as any)[k];
  (globalThis as any)[k] = typeof v === "function" && /^[a-z]/.test(k) ? v.bind(w) : v;
}
(globalThis as any).requestAnimationFrame = (f: () => void) => setTimeout(f, 0);
const { createEditor } = await import("../../apps/desktop/src/editor/editor");
const { editorViewCtx, parserCtx } = await import("../../apps/desktop/node_modules/@milkdown/kit/lib/core.js");
const { undo } = await import("../../apps/desktop/node_modules/@milkdown/kit/lib/prose/history.js");
const editor = await createEditor(document.body.appendChild(document.createElement("div")) as any, "Before.\n\nMy sentence.\n\nAfter.\n", () => {});
try {
  editor.action((ctx) => {
    const view = ctx.get(editorViewCtx);
    view.dispatch(view.state.tr.insertText("Typed ", 10));
    const next = ctx.get(parserCtx)("Outside before.\n\nTyped My sentence.\n\nOutside after.\n")!;
    const old = view.state.doc;
    const from = old.content.findDiffStart(next.content)!;
    const end = old.content.findDiffEnd(next.content)!;
    view.dispatch(view.state.tr.replace(from, end.a, next.slice(from, end.b)).setMeta("addToHistory", false));
    const undone = undo(view.state, view.dispatch);
    console.log({ undone, text: view.state.doc.textContent });
  });
} finally {
  await editor.destroy();
  await w.happyDOM.close();
}
