// Run with bun codex-out/editor/f1-red.ts. Real NoteBody + Milkdown, no browser.
import { createRequire } from "node:module";
const require = createRequire(new URL("../../apps/desktop/package.json", import.meta.url));
const { Window } = await import(require.resolve("happy-dom"));
import { strict as assert } from "node:assert";
const w = new Window();
for (const k of ["window", "document", "HTMLElement", "Element", "Node", "MutationObserver", "getComputedStyle", "navigator", "DOMParser", "ResizeObserver"] as const) {
  const v = (w as any)[k];
  (globalThis as any)[k] = typeof v === "function" && /^[a-z]/.test(k) ? v.bind(w) : v;
}
(globalThis as any).requestAnimationFrame = (f: () => void) => setTimeout(f, 0);
(globalThis as any).cancelAnimationFrame = clearTimeout;
(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;
const { createElement, act } = await import(require.resolve("react"));
const { createRoot } = await import(require.resolve("react-dom/client"));
const { undo } = await import("../../apps/desktop/node_modules/@milkdown/kit/lib/prose/history.js");
const { EditorView } = await import("../../apps/desktop/node_modules/@milkdown/kit/lib/prose/view.js");
let current: any;
const someProp = EditorView.prototype.someProp;
EditorView.prototype.someProp = function (...args: any[]) { current = this; return someProp.apply(this, args); };
const { NoteBody } = await import("../../apps/desktop/src/Notes");
const host = document.body.appendChild(document.createElement("div"));
const root = createRoot(host);
let notes: any = {
  text: "My sentence.\n", dir: "/tmp/f1-note", version: 0, error: null,
  edit: () => {}, flush: async () => true, close: () => {}, attach: async () => null,
  args: ["f1"], notify: () => {}, pull: { current: null },
};
const draw = async () => {
  await act(async () => {
    root.render(createElement(NoteBody, { notes, editorRef: { current: null }, targets: [], onOpen: () => {}, placeholder: "", label: "Source note" }));
    await new Promise((r) => setTimeout(r, 50));
  });
  await act(async () => { await new Promise((r) => setTimeout(r, 50)); });
};
const view = () => current;
try {
  await draw();
  const before = view();
  await act(async () => before.dispatch(before.state.tr.insertText("Typed ", 1)));
  notes = { ...notes, text: "Typed My sentence.\n\nOutside paragraph.\n", version: 1 };
  await draw();
  const after = view();
  let undone = false;
  await act(async () => { undone = undo(after.state, after.dispatch); });
  console.log({ remounted: before !== after, undone, text: after.state.doc.textContent });
  assert.equal(undone, true, "F1: an outside update must preserve the note's typing undo history");
} finally {
  await act(async () => root.unmount());
  await w.happyDOM.close();
}
