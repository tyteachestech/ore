import { strict as assert } from "node:assert";
import { readFileSync } from "node:fs";
const files = ["IconPicker.tsx", "Reader.tsx"];
const found = files.flatMap((name) => {
  const text = readFileSync(new URL(`../../apps/desktop/src/${name}`, import.meta.url), "utf8");
  return [...text.matchAll(/<(?:button|span)\b[^>]*\btitle=(?:\{label\(icon\)\}|"Play from here")/g)].map((m) => ({ file: name, line: text.slice(0, m.index).split("\n").length }));
});
console.log(found);
assert.deepEqual(found, [], "F548: icon cells and transcript timestamps still use native title hints");
